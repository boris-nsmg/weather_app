// things to add: search drop down with options for cities/countries

loadCurrentCity();
let coords = [];
let endPointHours = 10;
let endPointDays = 7;

const cityNameEl = document.querySelector(".city-name");
const searchBoxEl = document.querySelector(".search-box");
const hiddenButtonEl = document.querySelector(".hidden-button");
const currentTempEl = document.querySelector(".current-temp");
const currentFeelsLike = document.querySelector(".current-feels-like");
const currentWeatherEl = document.querySelector(".current-weather");
const hourlyForecastEl = document.querySelector(".hourly-forecast");
const hourlyForecastTableEl = hourlyForecastEl.firstChild;
const dailyForecastEl = document.querySelector(".daily-forecast");
const dailyForecastTableEl = dailyForecastEl.firstChild;

searchBoxEl.addEventListener("change", function () {
    renderCityData(this.value);
});

searchBoxEl.addEventListener('input', function () {
    if (searchBoxEl && searchBoxEl.value) {
        hiddenButtonEl.classList.add('hidden-button-changed');
        hiddenButtonEl.addEventListener('click', function () {
            searchBoxEl.value = null;
            hiddenButtonEl.classList.remove('hidden-button-changed');
        });
    } else {
        hiddenButtonEl.classList.remove('hidden-button-changed');
    };
});

async function apiFetch(url) {
    try {
        const response = await fetch(url);
        return await response.json();
    } catch (error) {
        console.log(error);
    };
};

async function ipLookUp() {
    const url = `http://ip-api.com/json`;
    try {
        const response = await fetch(url);
        return await response.json();
    } catch (error) {
        console.log(error);
    };
};

async function loadCurrentCity() {
    const data = await ipLookUp();
    if (data.status === 'success') {
        renderCityData(data.city);
    } else {
        console.log("Couldn't load current city");
    };
};

async function getCityCoords(input) {
    const url = `http://api.openweathermap.org/geo/1.0/direct?q=${input}&limit=1&appid=211158a74590af681a5f6a978c12427e`;
    return await apiFetch(url);
};

async function renderCityData(input) {
    const data = await getCityCoords(input);
    cityNameEl.textContent = data[0].name;
    coords = [data[0].lat, data[0].lon];
    endPointHours = 10;
    endPointDays = 7;
    renderCurrentWeather(coords);
    renderHourlyDailyWeather(coords);
};

async function getCurrentWeather(coords) {
    const url = `http://api.openweathermap.org/data/2.5/weather?lat=${coords[0]}&lon=${coords[1]}&units=metric&appid=211158a74590af681a5f6a978c12427e`;
    return await apiFetch(url)
};

async function renderCurrentWeather(coords) {
    const data = await getCurrentWeather(coords);
    currentTempEl.innerHTML = data.main.temp + '&#176';
    currentFeelsLike.innerHTML = 'Feels like: ' + data.main.feels_like + '&#176';
    currentWeatherEl.textContent = data.weather[0].description;
};

function showMoreBtn(section) {
    if (section === 'hourlyForecast') {
        if (hourlyForecastEl.style.display === 'none') {
            hourlyForecastEl.style.display = 'block';
        } else {
            hourlyForecastEl.style.display = 'none';
        };
    } else if (section === 'dailyForecast') {
        if (dailyForecastEl.style.display === 'none') {
            dailyForecastEl.style.display = 'block';
        } else {
            dailyForecastEl.style.display = 'none';
        };
    }
};

async function getHourlyDailyWeather(coords) {
    const url = `https://api.openweathermap.org/data/2.5/onecall?lat=${coords[0]}&lon=${coords[1]}&exclude=minutely,alerts&units=metric&appid=211158a74590af681a5f6a978c12427e`;
    return await apiFetch(url);
};

async function renderHourlyDailyWeather(coords, onlyRenderOne) {
    const data = await getHourlyDailyWeather(coords);
    if (onlyRenderOne) {
        if (onlyRenderOne === 'hourly') {
            renderHourlyWeather(data.hourly);
        } else if (onlyRenderOne === 'daily') {
            renderDailyWeather(data.daily);
        } else {
            console.log('Invalid value for onlyRenderOne parameter');
        };
    } else {
        renderHourlyWeather(data.hourly, 0);
        renderDailyWeather(data.daily);
    };
};

function renderHourlyWeather(hours) {
    let hourlyData = [];
    for (let i = 0; i < endPointHours; i++) {
        const hour = hours[i];
        const fullDate = new Date(hour.dt * 1000);
        const time = fullDate.getHours() + ':00';
        const temp = hour.temp + '&#176';
        const weather = hour.weather[0].main;
        const hourArray = [time, temp, weather];
        hourlyData.push(hourArray);
    };
    endPointHours += 3;

    if (hourlyForecastEl.childNodes.length !== 0) {
        hourlyForecastEl.removeChild(hourlyForecastEl.firstChild);
    };

    let newTable = document.createElement('table');
    hourlyData.forEach(array => {
        let newRow = document.createElement('tr');
        for (let i = 0; i < array.length; i++) {
            let newData = document.createElement('td');
            newData.innerHTML = array[i];
            if (i === 1) {
                newData.classList.add('table-temp');
            };
            newRow.appendChild(newData);
        };
        newTable.appendChild(newRow);
    });

    let buttonSpan = document.createElement('span');
    buttonSpan.classList.add('expand-table-button');
    let button = document.createElement('button');
    button.setAttribute("onclick", "expandTable('hourly')");
    buttonSpan.appendChild(button);
    newTable.appendChild(buttonSpan);
    hourlyForecastEl.appendChild(newTable);
};

function renderDailyWeather(days) {
    let dailyData = [];
    for (let i = 0; i < endPointDays; i++) {
        const day = days[i];
        const fullDate = new Date(day.dt * 1000);
        const date = fullDate.toString().slice(0, 3);
        const avgTemp = day.temp.day + '&#176';
        const minTemp = 'Min: ' + day.temp.min + '&#176';
        const maxTemp = 'Max: ' + day.temp.max + '&#176';
        const weather = day.weather[0].main;
        const dayArray = [date, avgTemp, minTemp, maxTemp, weather];
        dailyData.push(dayArray);
    };
    endPointDays += 1;

    if (dailyForecastEl.childNodes.length !== 0) {
        dailyForecastEl.removeChild(dailyForecastEl.firstChild);
    };

    let newTable = document.createElement('table');
    dailyData.forEach(array => {
        let newRow = document.createElement('tr');
        for (let i = 0; i < array.length; i++) {
            let newData = document.createElement('td');
            newData.innerHTML = array[i];
            if (i === 1) {
                newData.classList.add('table-temp');
            };
            newRow.appendChild(newData);
        };
        newTable.appendChild(newRow);
    });

    let buttonSpan = document.createElement('span');
    buttonSpan.classList.add('expand-table-button');
    let button = document.createElement('button');
    button.setAttribute("onclick", "expandTable('daily')");
    buttonSpan.appendChild(button);
    newTable.appendChild(buttonSpan);
    dailyForecastEl.appendChild(newTable);
};

function expandTable(table) {
    renderHourlyDailyWeather(coords, table);
};